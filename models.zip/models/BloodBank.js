import mongoose from "mongoose";
const BloodBankSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  address: {
    type: String,
    required: true,
  },
  phone: {
    type: String,
    required: true,
  },
 
 
  time: {
    type: String,

  },
BloodGroup: [
  {
    AvalibleBloodGroup: String,
    quantity: Number,
  }
]


});

export default mongoose.model("BloodBank", BloodBankSchema)