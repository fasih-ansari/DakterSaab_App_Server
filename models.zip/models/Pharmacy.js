import mongoose from "mongoose";


const MedicineSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true },
    category: { type: String, required: true },
  });
const PharmacySchema = new mongoose.Schema({
    pharmacyname: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    time: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    medicine:[MedicineSchema]
},
    { timestamps: true });


export default mongoose.model("Pharmacy", PharmacySchema)





// import mongoose from "mongoose";

// const PharmacySchema = new mongoose.Schema({
//     // ------ For pharmacy ------
//     pharmacyname: {
//         type: String,
//         required: true
//     },
//     address: {
//         type: String,
//         required: true
//     },
//     city: {
//         type: String,
//         required: true
//     },
//     country: {
//         type: String,
//         required: true
//     },
//     phone: {
//         type: String,
//         required: true
//     },
//     email: {
//         type: String,
//         required: true,
//         unique: true
//     },
//     // For medicine
//     medicine: {
//         type: String,
//         required: true
//     },
//     category:
//         [{
//             type: String,
//             required: true
//         }],
//     quantity: {
//         type: Number,
//         required: true
//     },
//     price: {
//         type: Number,
//         required: true
//     },
//     // timestamps: true ,
// });

// export default mongoose.model("Pharmacy", PharmacySchema)


// import mongoose from "mongoose";

// const PharmacySchema = new mongoose.Schema({
//     pharmacyname: {
//         type: String,
//         required: true
//     },
//     address: {
//         type: String,
//         required: true
//     },
//     city: {
//         type: String,
//         required: true
//     },
//     time:{
//         type: String,
//         required: true
//     },
//     phone: {
//         type: String,
//         required: true
//     },
//     email: {
//         type: String,
//         required: true,
//         unique: true
//     },
// });


// const MedicineSchema = new mongoose.Schema
//     ({
//         medicine:
//             [
//                 { name: { type: String, required: true } },
//                 { price: { type: Number, required: true } },
//                 { quantity: { type: Number, required: true } },
//                 { category: [{ type: String, required: true }] },
//                 { pharmacy: [PharmacySchema] },
//             ],
//     },
//         { timestamps: true });

// export default mongoose.model("Medicine", MedicineSchema)